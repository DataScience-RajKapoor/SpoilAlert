.. blinkpy documentation master file, created by
   sphinx-quickstart on Sat Jan 20 22:20:16 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to blinkpy's documentation!
===================================

.. toctree::
   :maxdepth: 1
   :caption: Contents:
   :glob:
   
   README
   advanced
   CONTRIBUTING
   modules/*
   CHANGES


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
