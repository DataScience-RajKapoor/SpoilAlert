for name, camera in blink.cameras.items():
  print(name)                   # Name of the camera
  print(camera.attributes)    
